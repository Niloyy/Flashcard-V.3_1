package com.niloy.flashcard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import java.text.Normalizer

private val SUP_MAP = mapOf(
    '0' to '⁰', '1' to '¹', '2' to '²', '3' to '³', '4' to '⁴',
    '5' to '⁵', '6' to '⁶', '7' to '⁷', '8' to '⁸', '9' to '⁹',
    '+' to '⁺', '-' to '⁻', '=' to '⁼', '(' to '⁽', ')' to '⁾',
    'a' to 'ᵃ', 'b' to 'ᵇ', 'c' to 'ᶜ', 'd' to 'ᵈ', 'e' to 'ᵉ', 'f' to 'ᶠ',
    'g' to 'ᵍ', 'h' to 'ʰ', 'i' to 'ⁱ', 'j' to 'ʲ', 'k' to 'ᵏ', 'l' to 'ˡ',
    'm' to 'ᵐ', 'n' to 'ⁿ', 'o' to 'ᵒ', 'p' to 'ᵖ', 'r' to 'ʳ', 's' to 'ˢ',
    't' to 'ᵗ', 'u' to 'ᵘ', 'v' to 'ᵛ', 'w' to 'ʷ', 'x' to 'ˣ', 'y' to 'ʸ', 'z' to 'ᶻ'
)

private val SUB_MAP = mapOf(
    '0' to '₀', '1' to '₁', '2' to '₂', '3' to '₃', '4' to '₄',
    '5' to '₅', '6' to '₆', '7' to '₇', '8' to '₈', '9' to '₉',
    '+' to '₊', '-' to '₋', '=' to '₌', '(' to '₍', ')' to '₎',
    'a' to 'ₐ', 'e' to 'ₑ', 'h' to 'ₕ', 'i' to 'ᵢ', 'j' to 'ⱼ', 'k' to 'ₖ',
    'l' to 'ₗ', 'm' to 'ₘ', 'n' to 'ₙ', 'o' to 'ₒ', 'p' to 'ₚ', 'r' to 'ᵣ',
    's' to 'ₛ', 't' to 'ₜ', 'u' to 'ᵤ', 'v' to 'ᵥ', 'x' to 'ₓ'
)

/** Answer compare korar age normalize: space, ^, _, {} bad; superscript/subscript -> normal; case ignore. */
fun normalizeAnswer(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFKC)
        .lowercase()
        .replace('\u2044', '/')
        .replace('\u2212', '-')
        .replace(Regex("[\\s^_{}]"), "")

class MathInputState(initial: String = "") {
    var text by mutableStateOf(initial)
    var cursor by mutableIntStateOf(initial.length)
    var shift by mutableStateOf(false)
    /** 0 = normal, 1 = superscript, 2 = subscript */
    var script by mutableIntStateOf(0)

    /** Normal key press: shift ar sup/sub mode apply hoy. */
    fun type(s: String) {
        var out = s
        if (shift) {
            out = out.uppercase()
            shift = false
        }
        out = when (script) {
            1 -> out.map { SUP_MAP[it.lowercaseChar()] ?: it }.joinToString("")
            2 -> out.map { SUB_MAP[it.lowercaseChar()] ?: it }.joinToString("")
            else -> out
        }
        insert(out)
    }

    /** Hubohu insert kore; cursorOffset diye cursor kothay thakbe thik kora jay. */
    fun insert(s: String, cursorOffset: Int = s.length) {
        val c = cursor.coerceIn(0, text.length)
        text = text.substring(0, c) + s + text.substring(c)
        cursor = c + cursorOffset
    }

    fun backspace() {
        val c = cursor.coerceIn(0, text.length)
        if (c > 0) {
            text = text.removeRange(c - 1, c)
            cursor = c - 1
        }
    }

    fun clear() {
        text = ""
        cursor = 0
    }

    fun left() {
        if (cursor > 0) cursor--
    }

    fun right() {
        if (cursor < text.length) cursor++
    }
}

@Composable
fun MathField(
    state: MathInputState,
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    lines: Int = 3,
    onClick: () -> Unit = {}
) {
    val borderColor = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    val lineHeightDp = 28.dp
    val lineHeightSp = with(LocalDensity.current) { lineHeightDp.toSp() }
    val c = state.cursor.coerceIn(0, state.text.length)
    val shown = buildAnnotatedString {
        append(state.text.substring(0, c))
        if (active) {
            withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)) {
                append("|")
            }
        }
        append(state.text.substring(c))
    }
    Column(modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = borderColor)
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(lineHeightDp * lines + 16.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFFAF5E6))
                .border(1.5.dp, borderColor, RoundedCornerShape(8.dp))
                .drawBehind {
                    for (i in 1..lines) {
                        val y = 8.dp.toPx() + lineHeightDp.toPx() * i
                        drawLine(
                            color = Color(0xFFB9B3A4).copy(alpha = 0.7f),
                            start = Offset(12.dp.toPx(), y),
                            end = Offset(size.width - 12.dp.toPx(), y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                }
                .clickable(onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(
                shown,
                style = TextStyle(
                    fontFamily = FontFamily.Serif,
                    fontSize = 18.sp,
                    lineHeight = lineHeightSp,
                    color = Color(0xFF1D2B30)
                ),
                modifier = Modifier.verticalScroll(rememberScrollState())
            )
        }
    }
}

@Composable
private fun RowScope.KeyBox(
    label: String,
    w: Float = 1f,
    active: Boolean = false,
    onClick: () -> Unit
) {
    val bg = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val fg = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Column(
        Modifier
            .weight(w)
            .padding(2.dp)
            .height(42.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(label, color = fg, fontSize = 17.sp, maxLines = 1)
    }
}

@Composable
private fun TypeRow(keys: List<String>, state: MathInputState) {
    Row(Modifier.fillMaxWidth()) {
        keys.forEach { k -> KeyBox(k) { state.type(k) } }
    }
}

@Composable
private fun InsertRow(keys: List<String>, state: MathInputState) {
    Row(Modifier.fillMaxWidth()) {
        keys.forEach { k -> KeyBox(k) { state.insert(k) } }
    }
}

@Composable
private fun FuncRow(keys: List<String>, state: MathInputState) {
    Row(Modifier.fillMaxWidth()) {
        keys.forEach { k -> KeyBox(k) { state.insert("$k()", k.length + 1) } }
    }
}

@Composable
fun MathKeyboard(state: MathInputState, modifier: Modifier = Modifier) {
    var page by remember { mutableIntStateOf(0) }

    Column(
        modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(4.dp)
    ) {
        when (page) {
            // ---------- ABC ----------
            0 -> {
                TypeRow("qwertyuiop".map { it.toString() }, state)
                Row(Modifier.fillMaxWidth()) {
                    Spacer(Modifier.weight(0.5f))
                    "asdfghjkl".forEach { ch -> KeyBox(ch.toString()) { state.type(ch.toString()) } }
                    Spacer(Modifier.weight(0.5f))
                }
                Row(Modifier.fillMaxWidth()) {
                    KeyBox("⇧", 1.5f, state.shift) { state.shift = !state.shift }
                    "zxcvbnm".forEach { ch -> KeyBox(ch.toString()) { state.type(ch.toString()) } }
                    KeyBox("⌫", 1.5f) { state.backspace() }
                }
                Row(Modifier.fillMaxWidth()) {
                    KeyBox("123", 1.3f) { page = 1 }
                    KeyBox("Σ", 1.3f) { page = 2 }
                    KeyBox("A²", 1.2f, state.script == 1) { state.script = if (state.script == 1) 0 else 1 }
                    KeyBox("A₂", 1.2f, state.script == 2) { state.script = if (state.script == 2) 0 else 2 }
                    KeyBox("space", 3f) { state.insert(" ") }
                    KeyBox("◀") { state.left() }
                    KeyBox("▶") { state.right() }
                }
            }
            // ---------- 123 / operators ----------
            1 -> {
                TypeRow("1234567890".map { it.toString() }, state)
                TypeRow(listOf("+", "-", "×", "÷", "=", "(", ")", "/", "^", "."), state)
                Row(Modifier.fillMaxWidth()) {
                    KeyBox("a/b", 1.3f) { state.insert("()/()", 1) }
                    KeyBox("√", 1f) { state.insert("√()", 2) }
                    KeyBox("x²") { state.insert("²") }
                    KeyBox("x³") { state.insert("³") }
                    KeyBox("xⁿ") { state.insert("ⁿ") }
                    KeyBox("x⁻¹", 1.2f) { state.insert("⁻¹") }
                    KeyBox("π") { state.insert("π") }
                    KeyBox("⌫", 1.3f) { state.backspace() }
                }
                Row(Modifier.fillMaxWidth()) {
                    KeyBox("ABC", 1.3f) { page = 0 }
                    KeyBox("Σ", 1.3f) { page = 2 }
                    KeyBox("A²", 1f, state.script == 1) { state.script = if (state.script == 1) 0 else 1 }
                    KeyBox("A₂", 1f, state.script == 2) { state.script = if (state.script == 2) 0 else 2 }
                    KeyBox("°") { state.insert("°") }
                    KeyBox("%") { state.insert("%") }
                    KeyBox("±") { state.insert("±") }
                    KeyBox("◀") { state.left() }
                    KeyBox("▶") { state.right() }
                }
            }
            // ---------- Greek / science symbols ----------
            else -> {
                InsertRow(listOf("α", "β", "γ", "δ", "ε", "θ", "λ", "μ", "ρ", "σ"), state)
                InsertRow(listOf("τ", "φ", "ω", "Δ", "Ω", "Σ", "Π", "ψ", "η", "ν"), state)
                InsertRow(listOf("∞", "≈", "≠", "≤", "≥", "→", "⇌", "∫", "∂", "∇"), state)
                FuncRow(listOf("sin", "cos", "tan", "log", "ln", "exp"), state)
                Row(Modifier.fillMaxWidth()) {
                    KeyBox("ABC", 1.3f) { page = 0 }
                    KeyBox("123", 1.3f) { page = 1 }
                    KeyBox("°") { state.insert("°") }
                    KeyBox("Å") { state.insert("Å") }
                    KeyBox("∝") { state.insert("∝") }
                    KeyBox("·") { state.insert("·") }
                    KeyBox("◀") { state.left() }
                    KeyBox("▶") { state.right() }
                    KeyBox("⌫", 1.3f) { state.backspace() }
                }
            }
        }
    }
}
