package com.niloy.flashcard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Paper {
    val Cream = Color(0xFFF6F1E4)
    val Card = Color(0xFFFBF8EF)
    val Teal = Color(0xFF2F6F7E)
    val TealDark = Color(0xFF1F5563)
    val Ink = Color(0xFF1D2B30)
    val Sky = Color(0xFFBBD5DC)
    val Ochre = Color(0xFFE6CD94)
    val Sage = Color(0xFFBBCFB2)
    val Line = Color(0xFFB9B3A4)
    val Red = Color(0xFFC0504D)
    val Green = Color(0xFF3E8E5A)
}

private val LightScheme = lightColorScheme(
    primary = Paper.Teal,
    onPrimary = Color.White,
    secondary = Paper.TealDark,
    onSecondary = Color.White,
    background = Paper.Cream,
    onBackground = Paper.Ink,
    surface = Paper.Card,
    onSurface = Paper.Ink,
    surfaceVariant = Color(0xFFEDE6D3),
    onSurfaceVariant = Paper.Ink,
    outline = Paper.Line,
    primaryContainer = Paper.Sky,
    onPrimaryContainer = Paper.Ink
)

private val base = Typography()
private val AppTypography = base.copy(
    headlineMedium = base.headlineMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold),
    headlineSmall = base.headlineSmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, lineHeight = 34.sp),
    titleLarge = base.titleLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold),
    titleMedium = base.titleMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
)

@Composable
fun FlashcardTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightScheme, typography = AppTypography, content = content)
}

private fun DrawScope.wash(color: Color, cx: Float, cy: Float, radius: Float, alpha: Float) {
    val c = Offset(size.width * cx, size.height * cy)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(color.copy(alpha = alpha), color.copy(alpha = 0f)),
            center = c,
            radius = radius
        ),
        radius = radius,
        center = c
    )
}

/** Watercolor paper background: cream + soft rongin dag. */
@Composable
fun WatercolorBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier
            .background(Paper.Cream)
            .drawBehind {
                val m = size.minDimension
                wash(Paper.Sky, 0.12f, 0.10f, m * 0.95f, 0.75f)
                wash(Paper.Ochre, 0.95f, 0.22f, m * 0.75f, 0.60f)
                wash(Paper.Sage, 0.05f, 0.62f, m * 0.80f, 0.55f)
                wash(Paper.Sky, 0.90f, 0.88f, m * 0.95f, 0.70f)
            },
        content = content
    )
}

/** Stacked paper card (reference image er moto). */
@Composable
fun PaperCard(
    modifier: Modifier = Modifier,
    fill: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Box(modifier.padding(end = 8.dp, bottom = 10.dp)) {
        Box(
            Modifier
                .matchParentSize()
                .offset(8.dp, 10.dp)
                .shadow(3.dp, shape)
                .background(Color(0xFFEFE8D5), shape)
        )
        Box(
            Modifier
                .matchParentSize()
                .offset(4.dp, 5.dp)
                .shadow(3.dp, shape)
                .background(Color(0xFFF5F0E0), shape)
        )
        Column(
            Modifier
                .then(if (fill) Modifier.fillMaxSize() else Modifier.fillMaxWidth())
                .shadow(6.dp, shape)
                .clip(shape)
                .background(Paper.Card)
                .drawBehind {
                    val m = size.minDimension
                    wash(Paper.Sky, 0.08f, 0.05f, m * 0.9f, 0.55f)
                    wash(Paper.Ochre, 0.95f, 0.45f, m * 0.6f, 0.40f)
                    wash(Paper.Sky, 0.85f, 0.95f, m * 0.9f, 0.45f)
                }
                .padding(16.dp),
            content = content
        )
    }
}

/** Teal brush-style primary button. */
@Composable
fun BrushButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(topStart = 18.dp, topEnd = 12.dp, bottomEnd = 20.dp, bottomStart = 12.dp)
    Box(
        modifier
            .height(48.dp)
            .clip(shape)
            .background(
                brush = Brush.horizontalGradient(listOf(Paper.Teal, Paper.TealDark)),
                shape = shape,
                alpha = if (enabled) 1f else 0.4f
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text.uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

/** Cream secondary button. */
@Composable
fun SoftButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .height(48.dp)
            .clip(shape)
            .background(Color(0xFFF3ECD8), shape)
            .border(1.dp, Paper.Line, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text.uppercase(), color = Paper.Ink, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
    }
}
