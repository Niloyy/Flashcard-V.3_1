package com.niloy.flashcard

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("quiz_prefs", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    var minMinutes: Int
        get() = sp.getInt("min", 15)
        set(v) { sp.edit().putInt("min", v).apply() }

    var maxMinutes: Int
        get() = sp.getInt("max", 45)
        set(v) { sp.edit().putInt("max", v).apply() }

    var lockMinutes: Int
        get() = sp.getInt("lock", 5)
        set(v) { sp.edit().putInt("lock", v).apply() }
}
