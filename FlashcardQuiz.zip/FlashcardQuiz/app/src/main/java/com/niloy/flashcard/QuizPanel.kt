package com.niloy.flashcard

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class QuizMode { OVERLAY, PRACTICE }

/**
 * Ekta card er quiz UI (watercolor paper card design).
 * OVERLAY: thik hole dismiss, vul hole lockSeconds por por lock.
 * PRACTICE: app er bhitore practice, lock nai.
 */
@Composable
fun QuizPanel(
    card: Flashcard,
    mode: QuizMode,
    lockSeconds: Int,
    cardNumber: Int = 1,
    totalCards: Int = 1,
    onFinished: () -> Unit,
    onEmergency: () -> Unit = {}
) {
    val input = remember { MathInputState() }
    var result by remember { mutableStateOf<Boolean?>(null) }
    val inset = if (mode == QuizMode.OVERLAY) Modifier.systemBarsPadding() else Modifier

    WatercolorBackground(Modifier.fillMaxSize()) {
        Box(inset.fillMaxSize().padding(12.dp)) {
            val r = result
            when {
                r == null -> AskLayout(card, mode, input, cardNumber, totalCards) {
                    result = normalizeAnswer(input.text) == normalizeAnswer(card.answer)
                }
                r -> CorrectLayout(mode, onFinished)
                mode == QuizMode.OVERLAY -> LockLayout(card, lockSeconds, onFinished, onEmergency)
                else -> PracticeWrongLayout(card, onFinished)
            }
        }
    }
}

@Composable
private fun AskLayout(
    card: Flashcard,
    mode: QuizMode,
    input: MathInputState,
    cardNumber: Int,
    totalCards: Int,
    onCheck: () -> Unit
) {
    var hintShown by remember { mutableStateOf(false) }
    val answerTrim = card.answer.trim()
    val first = answerTrim.firstOrNull()?.toString() ?: ""
    val total = if (totalCards < 1) 1 else totalCards

    Column(Modifier.fillMaxSize()) {
        PaperCard(Modifier.weight(1f).fillMaxWidth(), fill = true) {
            if (mode == QuizMode.OVERLAY) {
                Text(
                    "QUIZ TIME",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 2.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    card.question,
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center
                )
            }
            MathField(input, "Your answer", active = true, lines = 3)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrushButton("Check", Modifier.weight(1f), enabled = input.text.isNotBlank()) { onCheck() }
                SoftButton("Clear", Modifier.weight(1f)) { input.clear() }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Deck: $total cards", style = MaterialTheme.typography.bodySmall)
                Text("Card $cardNumber of $total", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { cardNumber.toFloat() / total.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = Paper.Teal,
                trackColor = Paper.Sky
            )
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF1EAD6))
                    .clickable { hintShown = true }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("💡")
                Spacer(Modifier.width(8.dp))
                Text(
                    if (hintShown) "Starts with “$first” · ${answerTrim.length} characters"
                    else "Hint (tap)",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        MathKeyboard(input, Modifier.clip(RoundedCornerShape(14.dp)))
    }
}

@Composable
private fun CorrectLayout(mode: QuizMode, onFinished: () -> Unit) {
    val scale = remember { Animatable(0.3f) }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        if (mode == QuizMode.OVERLAY) {
            delay(900)
            onFinished()
        }
    }
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "✓",
            fontSize = 120.sp,
            color = Paper.Green,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
        )
        Text("Correct!", style = MaterialTheme.typography.headlineMedium, color = Paper.Green)
        if (mode == QuizMode.PRACTICE) {
            Spacer(Modifier.height(24.dp))
            BrushButton("Next", Modifier.width(160.dp)) { onFinished() }
        }
    }
}

@Composable
private fun PracticeWrongLayout(card: Flashcard, onFinished: () -> Unit) {
    val shake = rememberShake()
    PaperCard(Modifier.fillMaxSize().offset(x = shake.value.dp), fill = true) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("✗", fontSize = 90.sp, color = Paper.Red, fontWeight = FontWeight.Bold)
            Text("Not quite", style = MaterialTheme.typography.headlineMedium, color = Paper.Red)
            Spacer(Modifier.height(16.dp))
            Text("Correct answer", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            Text(
                card.answer,
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center,
                color = Paper.Green
            )
            Spacer(Modifier.height(24.dp))
            BrushButton("Next", Modifier.width(160.dp)) { onFinished() }
        }
    }
}

@Composable
private fun rememberShake(): Animatable<Float, AnimationVector1D> {
    val shake = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        shake.animateTo(
            0f,
            keyframes {
                durationMillis = 500
                -18f at 60
                18f at 160
                -14f at 260
                14f at 360
                -7f at 440
                0f at 500
            }
        )
    }
    return shake
}

@Composable
private fun LockLayout(
    card: Flashcard,
    lockSeconds: Int,
    onFinished: () -> Unit,
    onEmergency: () -> Unit
) {
    val totalMs = lockSeconds * 1000L
    val endAt = remember { SystemClock.elapsedRealtime() + totalMs }
    var remainingMs by remember { mutableLongStateOf(totalMs) }
    val shake = rememberShake()

    LaunchedEffect(Unit) {
        while (true) {
            val left = endAt - SystemClock.elapsedRealtime()
            if (left <= 0L) {
                remainingMs = 0L
                break
            }
            remainingMs = left
            delay(100)
        }
        onFinished()
    }

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseScale"
    )

    val totalSec = ((remainingMs + 999) / 1000).toInt()
    val timeText = "%d:%02d".format(totalSec / 60, totalSec % 60)
    val fraction = if (totalMs > 0) remainingMs.toFloat() / totalMs.toFloat() else 0f

    PaperCard(Modifier.fillMaxSize().offset(x = shake.value.dp), fill = true) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Not quite. Phone locked",
                style = MaterialTheme.typography.headlineMedium,
                color = Paper.Red,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))

            Box(
                Modifier
                    .size(210.dp)
                    .graphicsLayer {
                        scaleX = pulse
                        scaleY = pulse
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 14.dp.toPx()
                    val arcSize = Size(size.width - sw, size.height - sw)
                    val topLeft = Offset(sw / 2, sw / 2)
                    drawArc(
                        color = Paper.Sky,
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = sw, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = Paper.Teal,
                        startAngle = -90f,
                        sweepAngle = 360f * fraction,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = sw, cap = StrokeCap.Round)
                    )
                }
                Text(
                    timeText,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
            }

            Spacer(Modifier.height(24.dp))
            Text("Correct answer, ekhon mone rakho", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Text(
                card.answer,
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center,
                color = Paper.Green
            )

            Spacer(Modifier.height(28.dp))
            Text(
                "Emergency? Ekhane press kore dhore rakho",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier
                    .padding(12.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(onLongPress = { onEmergency() })
                    }
            )
        }
    }
}
