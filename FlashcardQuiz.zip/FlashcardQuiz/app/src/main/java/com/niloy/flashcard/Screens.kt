package com.niloy.flashcard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.roundToInt

@Composable
fun FlashcardApp(vm: CardViewModel = viewModel()) {
    val cards by vm.cards.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var editorOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Flashcard?>(null) }

    WatercolorBackground(Modifier.fillMaxSize()) {
        if (editorOpen) {
            EditorScreen(
                card = editing,
                onSave = { q, a ->
                    val target = editing
                    if (target == null) {
                        vm.add(q, a)
                    } else {
                        vm.update(target.copy(question = q.trim(), answer = a.trim()))
                    }
                    editorOpen = false
                },
                onCancel = { editorOpen = false }
            )
        } else {
            val itemColors = NavigationBarItemDefaults.colors(indicatorColor = Paper.Sky)
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        NavigationBarItem(
                            selected = tab == 0, onClick = { tab = 0 },
                            icon = { Text("🃏") }, label = { Text("Cards") }, colors = itemColors
                        )
                        NavigationBarItem(
                            selected = tab == 1, onClick = { tab = 1 },
                            icon = { Text("✏️") }, label = { Text("Practice") }, colors = itemColors
                        )
                        NavigationBarItem(
                            selected = tab == 2, onClick = { tab = 2 },
                            icon = { Text("⚙️") }, label = { Text("Settings") }, colors = itemColors
                        )
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (tab) {
                        0 -> CardsScreen(
                            cards = cards,
                            vm = vm,
                            onAdd = { editing = null; editorOpen = true },
                            onEdit = { editing = it; editorOpen = true }
                        )
                        1 -> PracticeScreen(cards)
                        else -> SettingsScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun CardsScreen(
    cards: List<Flashcard>,
    vm: CardViewModel,
    onAdd: () -> Unit,
    onEdit: (Flashcard) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 20.dp, top = 20.dp, end = 20.dp, bottom = 4.dp)) {
            Text("My Cards", style = MaterialTheme.typography.headlineMedium)
            Text("${cards.size} cards in your deck", style = MaterialTheme.typography.bodyMedium)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (cards.isEmpty()) {
                Text(
                    "Kono card nai. + ADD CARD chapo.",
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(cards, key = { it.id }) { card ->
                        PaperCard(Modifier.fillMaxWidth()) {
                            Text(card.question, style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(card.answer, color = Paper.TealDark)
                            Row {
                                TextButton(onClick = { onEdit(card) }) { Text("Edit") }
                                TextButton(onClick = { vm.delete(card) }) { Text("Delete") }
                            }
                        }
                    }
                }
            }

            ExtendedFloatingActionButton(
                onClick = onAdd,
                containerColor = Paper.Teal,
                contentColor = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Text("+ ADD CARD", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun EditorScreen(card: Flashcard?, onSave: (String, String) -> Unit, onCancel: () -> Unit) {
    BackHandler(onBack = onCancel)
    val q = remember { MathInputState(card?.question ?: "") }
    val a = remember { MathInputState(card?.answer ?: "") }
    var activeQ by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SoftButton("Cancel", Modifier.width(100.dp)) { onCancel() }
            Text(
                if (card == null) "New card" else "Edit card",
                style = MaterialTheme.typography.titleLarge
            )
            BrushButton("Save", Modifier.width(100.dp)) {
                if (q.text.isNotBlank() && a.text.isNotBlank()) onSave(q.text, a.text)
            }
        }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MathField(q, "QUESTION", activeQ, lines = 3) { activeQ = true }
            MathField(a, "ANSWER", !activeQ, lines = 3) { activeQ = false }
        }
        MathKeyboard(if (activeQ) q else a)
    }
}

@Composable
fun PracticeScreen(cards: List<Flashcard>) {
    if (cards.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Age Cards tab e kichu card add koro.")
        }
        return
    }
    var round by remember { mutableIntStateOf(0) }
    val card = remember(round) { cards.random() }
    val number = cards.indexOfFirst { it.id == card.id } + 1
    key(round) {
        QuizPanel(
            card = card,
            mode = QuizMode.PRACTICE,
            lockSeconds = 0,
            cardNumber = number,
            totalCards = cards.size,
            onFinished = { round++ }
        )
    }
}

private fun openOverlaySettings(ctx: Context) {
    Toast.makeText(
        ctx,
        "'Display over other apps' permission dao, tarpor back e ashe abar try koro",
        Toast.LENGTH_LONG
    ).show()
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
    )
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var enabled by remember { mutableStateOf(prefs.enabled) }
    var minM by remember { mutableIntStateOf(prefs.minMinutes) }
    var maxM by remember { mutableIntStateOf(prefs.maxMinutes) }
    var lockM by remember { mutableIntStateOf(prefs.lockMinutes) }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    fun restartIfEnabled() {
        if (enabled) QuizService.send(ctx, QuizService.ACTION_START)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Settings",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(start = 4.dp, top = 4.dp)
        )

        PaperCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Quiz mode", style = MaterialTheme.typography.titleMedium)
                    Text("Random somoy e quiz popup ashbe", style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = { on ->
                        if (on) {
                            if (!Settings.canDrawOverlays(ctx)) {
                                openOverlaySettings(ctx)
                            } else {
                                if (Build.VERSION.SDK_INT >= 33 &&
                                    ContextCompat.checkSelfPermission(
                                        ctx, Manifest.permission.POST_NOTIFICATIONS
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                prefs.enabled = true
                                enabled = true
                                QuizService.send(ctx, QuizService.ACTION_START)
                            }
                        } else {
                            prefs.enabled = false
                            enabled = false
                            QuizService.send(ctx, QuizService.ACTION_STOP)
                        }
                    }
                )
            }
        }

        PaperCard(Modifier.fillMaxWidth()) {
            Text("Timing", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text("Minimum interval: $minM min")
            Slider(
                value = minM.toFloat(),
                onValueChange = {
                    minM = it.roundToInt()
                    if (maxM < minM) maxM = minM
                    prefs.minMinutes = minM
                    prefs.maxMinutes = maxM
                },
                onValueChangeFinished = { restartIfEnabled() },
                valueRange = 1f..120f
            )
            Text("Maximum interval: $maxM min")
            Slider(
                value = maxM.toFloat(),
                onValueChange = {
                    maxM = it.roundToInt()
                    if (minM > maxM) minM = maxM
                    prefs.minMinutes = minM
                    prefs.maxMinutes = maxM
                },
                onValueChangeFinished = { restartIfEnabled() },
                valueRange = 1f..120f
            )
            Text("Vul hole lock: $lockM min")
            Slider(
                value = lockM.toFloat(),
                onValueChange = {
                    lockM = it.roundToInt()
                    prefs.lockMinutes = lockM
                },
                valueRange = 1f..15f
            )
        }

        BrushButton("Test quiz now (3 sec por)", Modifier.fillMaxWidth()) {
            if (!Settings.canDrawOverlays(ctx)) {
                openOverlaySettings(ctx)
            } else {
                QuizService.send(ctx, QuizService.ACTION_TEST)
                Toast.makeText(ctx, "3 sec por quiz ashbe", Toast.LENGTH_SHORT).show()
            }
        }

        Text(
            "Tip: prothome lock 1 min rekhe test koro. Battery optimization e ei app ke " +
                "'Unrestricted' koro, na hole system background e kill korte pare. " +
                "Phone restart dile quiz mode bondho hoye jay, app khule abar chalu korte hobe.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}
