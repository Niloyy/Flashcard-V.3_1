package com.niloy.flashcard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

/** ComposeView ke Service er overlay window e chalate lifecycle owner lage. */
private class OverlayOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = registry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateController.savedStateRegistry

    fun create() {
        savedStateController.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}

class QuizService : Service() {

    companion object {
        const val ACTION_START = "com.niloy.flashcard.START"
        const val ACTION_STOP = "com.niloy.flashcard.STOP"
        const val ACTION_TEST = "com.niloy.flashcard.TEST"
        private const val CHANNEL_ID = "quiz_mode"
        private const val NOTIF_ID = 1

        fun send(context: Context, action: String) {
            val intent = Intent(context, QuizService::class.java).setAction(action)
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager

    private var overlayRoot: FrameLayout? = null
    private var overlayOwner: OverlayOwner? = null

    private val showRunnable = Runnable { tryShow() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startAsForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        val prefs = Prefs(this)
        when (intent?.action) {
            ACTION_STOP -> {
                // quiz/lock cholar shomoy Stop kaj korbe na
                if (overlayRoot != null) return START_STICKY
                prefs.enabled = false
                handler.removeCallbacksAndMessages(null)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TEST -> {
                handler.postDelayed({ showOverlay() }, 3000)
                if (!prefs.enabled) return START_NOT_STICKY
            }
            else -> {
                if (!prefs.enabled) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                if (overlayRoot == null) scheduleNext()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeOverlay(restoreNotification = false)
        scope.cancel()
        super.onDestroy()
    }

    // ---------------- scheduling ----------------

    private fun scheduleNext() {
        handler.removeCallbacks(showRunnable)
        val prefs = Prefs(this)
        val minMs = prefs.minMinutes * 60_000L
        val maxMs = maxOf(prefs.maxMinutes, prefs.minMinutes) * 60_000L
        val delayMs = if (maxMs > minMs) Random.nextLong(minMs, maxMs + 1) else minMs
        handler.postDelayed(showRunnable, delayMs)
    }

    private fun tryShow() {
        if (overlayRoot != null) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) {
            // screen off, 30 sec por abar check
            handler.postDelayed(showRunnable, 30_000)
            return
        }
        showOverlay()
    }

    private fun afterDone() {
        if (Prefs(this).enabled) scheduleNext() else stopSelf()
    }

    // ---------------- overlay ----------------

    private fun showOverlay() {
        if (overlayRoot != null) return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission nai, quiz mode bondho", Toast.LENGTH_LONG).show()
            Prefs(this).enabled = false
            stopSelf()
            return
        }
        scope.launch {
            val cards = withContext(Dispatchers.IO) {
                AppDatabase.get(this@QuizService).cardDao().getAllOnce()
            }
            if (cards.isEmpty()) {
                afterDone()
                return@launch
            }
            if (overlayRoot != null) return@launch
            val lockSeconds = Prefs(this@QuizService).lockMinutes * 60
            val idx = cards.indices.random()
            addOverlay(cards[idx], idx + 1, cards.size, lockSeconds)
        }
    }

    private fun addOverlay(card: Flashcard, cardNumber: Int, totalCards: Int, lockSeconds: Int) {
        val service = this
        val mainHandler = handler
        val owner = OverlayOwner().also { it.create() }

        val root = object : FrameLayout(service) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) return true
                return super.dispatchKeyEvent(event)
            }
        }
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        root.setViewTreeLifecycleOwner(owner)
        root.setViewTreeSavedStateRegistryOwner(owner)
        root.setViewTreeViewModelStoreOwner(owner)

        val compose = ComposeView(service).apply {
            setContent {
                FlashcardTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        QuizPanel(
                            card = card,
                            mode = QuizMode.OVERLAY,
                            lockSeconds = lockSeconds,
                            cardNumber = cardNumber,
                            totalCards = totalCards,
                            onFinished = {
                                mainHandler.post {
                                    removeOverlay()
                                    afterDone()
                                }
                            },
                            onEmergency = {
                                mainHandler.post {
                                    removeOverlay()
                                    openDialer()
                                    afterDone()
                                }
                            }
                        )
                    }
                }
            }
        }
        root.addView(
            compose,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            Toast.makeText(service, "Overlay dekhano gelo na: ${e.message}", Toast.LENGTH_LONG).show()
            owner.destroy()
            afterDone()
            return
        }
        owner.resume()
        root.requestFocus()
        overlayRoot = root
        overlayOwner = owner
        postNotification(withStop = false)
    }

    private fun removeOverlay(restoreNotification: Boolean = true) {
        val root = overlayRoot ?: return
        (root.getChildAt(0) as? ComposeView)?.disposeComposition()
        try {
            wm.removeView(root)
        } catch (_: Exception) {
        }
        overlayOwner?.destroy()
        overlayRoot = null
        overlayOwner = null
        if (restoreNotification) postNotification(withStop = true)
    }

    private fun openDialer() {
        try {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    // ---------------- notification ----------------

    private fun buildNotification(withStop: Boolean): Notification {
        val openPi = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_card)
            .setContentTitle("Flashcard quiz mode ON")
            .setContentText(if (withStop) "Random somoy e quiz ashbe" else "Quiz cholche")
            .setContentIntent(openPi)
            .setOngoing(true)
        if (withStop) {
            val stopPi = PendingIntent.getService(
                this, 0,
                Intent(this, QuizService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(0, "Stop", stopPi)
        }
        return builder.build()
    }

    private fun postNotification(withStop: Boolean) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification(withStop))
        } catch (_: Exception) {
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Quiz mode", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = buildNotification(withStop = overlayRoot == null)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }
}
